using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.Rendering.RenderGraphModule;
using Unity.VisualScripting;
using UnityEngine.Rendering.RenderGraphModule.Util;
using System;
using SSOutlines;

public class SSORendererFeature : ScriptableRendererFeature
{
    [System.Serializable]
    private class OutlineMaterialSettings
    {
        public LayerMask outlinesLayerMask;
        [ColorUsage(true, true)] public Color OutlineColor = Color.black;
        public float OutlineScale = 2.0f;

        [Header("Depth Based Outlines")]    
        public float DepthThreshold = 1.5f;


        [Header("Roberts Cross Depth")]
        public float RobertsCrossMultiplier = 100.0f;
        public bool useNMS = false;

        [Tooltip("Outline scale factor for the Non-Maximum Suppression (NMS). Higher values mean that the NMS will look at a larger area for suppression, which results in the outline being closer to the main outline scale value.")]
        [Range(0.01f,1.0f)] public float NMS_OutlineScale = 0.7f;
    

        [Header("Depth Based Outlines Artifact Correction")]   
        public float SteepAngleThreshold = 0.5f;
        public float SteepAngleMultiplier = 25.0f;

        
        [Header("Normal Based Outlines")]
        public float NormalThreshold = 0.5f;
        public bool scaleNormalThresholdWithDistance = true;

        
        [Header("Distance Based Outline Scale")]
        public float DistancePow = 1.05f;
    }
    
    class AddOwnTexturePass : ScriptableRenderPass
    {

        private Matrix4x4 m_projectionMatrix;

        class PassData
        {
            internal TextureHandle copySourceTexture;
            internal Matrix4x4 projectionMatrix;
            internal Camera camera;
        }

        // Create the custom data class that contains the new textures
        public class CustomData : ContextItem {
            public TextureHandle newTextureForFrameData;
            public TextureHandle outlineTextureFrameData;
            public TextureHandle vsNormalFrameData;

            public override void Reset()
            {
                newTextureForFrameData = TextureHandle.nullHandle;
                outlineTextureFrameData = TextureHandle.nullHandle;
                vsNormalFrameData = TextureHandle.nullHandle;
            }
        }

        public void Setup(Matrix4x4 projectionMatrix)
        {
           m_projectionMatrix = projectionMatrix;
        }
       

        public override void RecordRenderGraph(RenderGraph renderGraph, ContextContainer frameData)
        {
            using (var builder = renderGraph.AddRasterRenderPass<PassData>("CreateCustomColorBuffers", out var passData))
            {
                //Debug.Log($"Screen: {Screen.width} x {Screen.height}");
                // Create a texture and set it as the render target
                RenderTextureDescriptor textureProperties = new RenderTextureDescriptor(Screen.width, Screen.height, RenderTextureFormat.Default, 0);
                textureProperties.enableRandomWrite = true;
                textureProperties.bindMS = false;
                textureProperties.volumeDepth = 1;
                textureProperties.depthBufferBits = 0;

                TextureHandle texture = UniversalRenderer.CreateRenderGraphTexture(renderGraph, textureProperties, "ColorBuffer - TRHistoryBackBuffer", true);
                TextureHandle outlineTexture = UniversalRenderer.CreateRenderGraphTexture(renderGraph, textureProperties, "ColorBuffer - OutlineBackBuffer", true);
                TextureHandle vsNormalTexture = UniversalRenderer.CreateRenderGraphTexture(renderGraph, textureProperties, "ColorBuffer - vsNormalBackBuffer", true);

                CustomData customData = frameData.Create<CustomData>();
                customData.newTextureForFrameData = texture;
                customData.outlineTextureFrameData = outlineTexture;
                customData.vsNormalFrameData = vsNormalTexture;

                UniversalCameraData cameraData = frameData.Get<UniversalCameraData>();
                passData.projectionMatrix = m_projectionMatrix;
                passData.camera = cameraData.camera;

                builder.SetRenderAttachment(texture, 0, AccessFlags.Write);
    
                builder.AllowPassCulling(false);

                builder.SetRenderFunc((PassData data, RasterGraphContext context) => ExecutePass(data, context));
            }
        }

        static void ExecutePass(PassData data, RasterGraphContext context)
        {   
            // Clear the render target 
            context.cmd.ClearRenderTarget(true, true, Color.clear);

            data.camera.projectionMatrix = data.projectionMatrix; 
            context.cmd.SetupCameraProperties(data.camera);
        }
 
    }

    class SSOutlinesPass : ScriptableRenderPass
    {
        class NormalsPassData
        {
            internal RendererListHandle objectsToDraw;
        }

        class NMSPassData
        {
            internal TextureHandle source;
            public Material material;

            public TextureHandle outlines;
            public string texName_outlines;
        }

        class PassData
        {
            internal TextureHandle source;
            public Material material;

            public TextureHandle depth;
            public string texName_depth;

            public TextureHandle vsnormal;
            public string texName_vsnormal;
        }

        const string m_PassName = "OutlinePass";
        Material m_Material;
        Material m_NormalsMaterial;
        Material m_NMSMaterial;
        OutlineMaterialSettings m_outlineMaterialSettings;
        

        const string m_texName_depth = "_DepthTexture";
        const string m_texName_outlines = "_OutlinesTexture";
        const string m_texName_vsnormal = "_ViewSpaceNormalsTexture";
        private TemporalReprojection m_temporalReprojection;

        public void Setup(Material material, Material nmsMaterial, Material normalsMaterial, OutlineMaterialSettings outlineMaterialSettings, TemporalReprojection temporalReprojection)
        {
            m_Material = material;
            m_NMSMaterial = nmsMaterial;
            m_NormalsMaterial = normalsMaterial;
            m_outlineMaterialSettings = outlineMaterialSettings;
            m_temporalReprojection = temporalReprojection;
        }

        private void SetMatieralProperties(int width, int height)
        {
            if(m_Material == null || m_outlineMaterialSettings == null) return;

            // Compute Jitter UV
            Vector4 jitterUV = m_temporalReprojection._frustumJitter.activeSample;
            jitterUV.x /= (float) width;
            jitterUV.y /= (float) height;
            jitterUV.z /= (float) width;
            jitterUV.w /= (float) height;

            m_Material.SetFloat("_OutlineScale", m_outlineMaterialSettings.OutlineScale);
            m_Material.SetFloat("_DepthThreshold", m_outlineMaterialSettings.DepthThreshold);
            m_Material.SetFloat("_RobertsCrossMultiplier", m_outlineMaterialSettings.RobertsCrossMultiplier);
            m_Material.SetFloat("_NormalThreshold", m_outlineMaterialSettings.NormalThreshold);
            m_Material.SetInt("_ScaleNormalThresholdWithDistance", m_outlineMaterialSettings.scaleNormalThresholdWithDistance ? 1 : 0);
            m_Material.SetFloat("_SteepAngleThreshold", m_outlineMaterialSettings.SteepAngleThreshold);
            m_Material.SetFloat("_SteepAngleMultiplier", m_outlineMaterialSettings.SteepAngleMultiplier);
            m_Material.SetFloat("_DistancePow", m_outlineMaterialSettings.DistancePow);
            m_Material.SetVector("_JitterUV", jitterUV);
            EffectBase.EnsureKeyword(m_Material, "USE_NMS", m_outlineMaterialSettings.useNMS);
        }

        private void SetNMSMatieralProperties()
        {
            if(m_NMSMaterial == null|| m_outlineMaterialSettings == null) return;

            float nmsAmount = m_outlineMaterialSettings.NMS_OutlineScale * m_outlineMaterialSettings.OutlineScale;
            
            m_NMSMaterial.SetColor("_OutlineColor", m_outlineMaterialSettings.OutlineColor);
            m_NMSMaterial.SetFloat("_NMSAmount", nmsAmount);
            EffectBase.EnsureKeyword(m_NMSMaterial, "USE_NMS", m_outlineMaterialSettings.useNMS);
        }

        public override void RecordRenderGraph(RenderGraph renderGraph, ContextContainer frameData)
        {
            
            using (var builder = renderGraph.AddRasterRenderPass<NormalsPassData>("ViewSpaceNormal Pass", out var passData))
            {
                var customData = frameData.Get<AddOwnTexturePass.CustomData>();
                var vsNormalBuffer = customData.vsNormalFrameData;
                
                
                if(!vsNormalBuffer.IsValid())
                {
                    Debug.LogError("Outlines: Invalid texture handle.");
                    return;
                }

                UniversalRenderingData renderingData = frameData.Get<UniversalRenderingData>();
                UniversalCameraData cameraData = frameData.Get<UniversalCameraData>();
                UniversalLightData lightData = frameData.Get<UniversalLightData>();
                SortingCriteria sortFlags = cameraData.defaultOpaqueSortFlags;
                RenderQueueRange renderQueueRange = RenderQueueRange.opaque;
                FilteringSettings filterSettings = new FilteringSettings(renderQueueRange, m_outlineMaterialSettings.outlinesLayerMask);

                // Redraw only objects that have their LightMode tag set to UniversalForward 
                ShaderTagId shadersToOverride = new ShaderTagId("UniversalForward");

                // Create drawing settings
                DrawingSettings drawSettings = RenderingUtils.CreateDrawingSettings(shadersToOverride, renderingData, cameraData, lightData, sortFlags);

                // Add the override material to the drawing settings
                drawSettings.overrideMaterial = m_NormalsMaterial;

                // Create the list of objects to draw
                var rendererListParameters = new RendererListParams(renderingData.cullResults, drawSettings, filterSettings);
                passData.objectsToDraw = renderGraph.CreateRendererList(rendererListParameters);


                // Create a depth texture
                RenderTextureDescriptor depthTextureProperties = new RenderTextureDescriptor(Screen.width, Screen.height, RenderTextureFormat.Depth, 24);
                depthTextureProperties.enableRandomWrite = false;
                depthTextureProperties.bindMS = false;
                depthTextureProperties.volumeDepth = 1;
                depthTextureProperties.depthBufferBits = 24; // Depth buffer

                TextureHandle depthTexture = UniversalRenderer.CreateRenderGraphTexture(renderGraph, depthTextureProperties, "DepthBuffer", true);

                builder.SetRenderAttachment(vsNormalBuffer, 0, AccessFlags.Write); // Color attachment
                builder.SetRenderAttachmentDepth(depthTexture, AccessFlags.Write); // Depth attachment

                builder.UseRendererList(passData.objectsToDraw);

                builder.AllowPassCulling(false);

                builder.SetRenderFunc((NormalsPassData data, RasterGraphContext rgContext) =>  {
                    
                    rgContext.cmd.ClearRenderTarget(RTClearFlags.Color | RTClearFlags.Depth, Color.clear, 1,0);
                    rgContext.cmd.DrawRendererList(data.objectsToDraw);
                });
            }
            

            using (var builder = renderGraph.AddRasterRenderPass<PassData>(m_PassName, out var passData))
            {
                var resourceData = frameData.Get<UniversalResourceData>();

                var customData = frameData.Get<AddOwnTexturePass.CustomData>();
                var outlineBackBuffer = customData.outlineTextureFrameData;
                var vsNormalBuffer = customData.vsNormalFrameData;
                
                if(!outlineBackBuffer.IsValid() || !vsNormalBuffer.IsValid())
                {
                    Debug.LogError("Outlines: Invalid texture handle.");
                    return;
                }


                passData.source = resourceData.activeColorTexture;
                
                // Use the camera's depth attachment as input.
                passData.depth = resourceData.activeDepthTexture;
                passData.texName_depth = m_texName_depth;

                // use the custom normal texture for normals
                passData.vsnormal = vsNormalBuffer;
                passData.texName_vsnormal = m_texName_vsnormal;

                SetMatieralProperties(Screen.width, Screen.height);

                passData.material = m_Material;

                
                builder.UseTexture(passData.depth, AccessFlags.Read);
                builder.UseTexture(passData.vsnormal, AccessFlags.Read);

                // write to the outline texture
                builder.SetRenderAttachment(outlineBackBuffer, 0, AccessFlags.Write);

                builder.AllowPassCulling(false);

                builder.SetRenderFunc((PassData data, RasterGraphContext rgContext) =>  {
                    data.material.SetTexture(data.texName_depth, data.depth);
                    data.material.SetTexture(data.texName_vsnormal, data.vsnormal);

                    // Perform the blit
                    Blitter.BlitTexture(rgContext.cmd, data.source, new Vector4(1.0f, 1.0f, 0, 0), data.material, 0);
                });
            }

            
            using (var builder = renderGraph.AddRasterRenderPass<NMSPassData>("NMS Pass", out var passData))
            {
                var resourceData = frameData.Get<UniversalResourceData>();

                var customData = frameData.Get<AddOwnTexturePass.CustomData>();
                var outlineBackBuffer = customData.outlineTextureFrameData;

                if(!outlineBackBuffer.IsValid())
                {
                    Debug.LogError("Outlines: Invalid texture handle.");
                    return;
                }

                passData.source = resourceData.activeColorTexture;

                // read from the outline texture
                passData.outlines = outlineBackBuffer;
                passData.texName_outlines = m_texName_outlines;

                SetNMSMatieralProperties();

                passData.material = m_NMSMaterial;

                var source = resourceData.activeColorTexture;
                var destinationDesc = renderGraph.GetTextureDesc(source);
                destinationDesc.name = $"CameraColor-{m_PassName}";
                destinationDesc.clearBuffer = false;

                TextureHandle destination = renderGraph.CreateTexture(destinationDesc);

                builder.UseTexture(passData.outlines);

                builder.SetRenderAttachment(destination, 0, AccessFlags.Write);

                builder.SetRenderFunc((NMSPassData data, RasterGraphContext rgContext) =>
                {
                    data.material.SetTexture(data.texName_outlines, data.outlines);
                    Blitter.BlitTexture(rgContext.cmd, data.source, new Vector4(1.0f, 1.0f, 0, 0), data.material, 0);
                });

                resourceData.cameraColor = destination;
            }
            
        }

    }

    class TemporalReprojectionPass : ScriptableRenderPass
    {
        // The data we want to transfer to the render function after recording.
        class BlitPassData
        {
            internal TextureHandle textureToRead;
            public Material material;
        }

        class PassData
        {
            // Texture handle for the color input.
            public TextureHandle color;
            // Input texture name for the material.
            public string texName_color;
            // Material used for the MRT Pass.
            public Material material;


            public TextureHandle depth;
            public string texName_depth;

            public TextureHandle history;
            public string texName_history;

            public TextureHandle motionvectors;
            public string texName_motionvectors;

        }

        const string m_PassName = "Temporal Reprojection";
        const string m_texName_color = "_ColorTexture";
        const string m_texName_depth = "_DepthTex";
        const string m_texName_history = "_HistoryTexture";
        const string m_texName_motionvectors = "_MotionVectorTexture";
        

        Material m_Material;
        RTHandle[] m_RTs = new RTHandle[2];
        TemporalReprojection m_temporalReprojection;
   


        public void Setup(Material material, TemporalReprojection temporalReprojection)
        {
            m_Material = material;
            m_temporalReprojection = temporalReprojection;

            RenderTextureDescriptor textureProperties = new RenderTextureDescriptor(Screen.width, Screen.height, RenderTextureFormat.Default, 0);
            RenderingUtils.ReAllocateIfNeeded(ref m_RTs[0], textureProperties, FilterMode.Bilinear, TextureWrapMode.Clamp, name: "TRHistoryBuffer" );
            RenderingUtils.ReAllocateIfNeeded(ref m_RTs[1], textureProperties, FilterMode.Bilinear, TextureWrapMode.Clamp, name: "TRScreenBuffer" );
        }


        private void SetMatieralProperties(Material reprojectionMaterial, int width, int height)
        {
            if(reprojectionMaterial == null || m_temporalReprojection == null) return;

            // Compute Jitter UV
            Vector4 jitterUV = m_temporalReprojection._frustumJitter.activeSample;
            jitterUV.x /= (float) width;
            jitterUV.y /= (float) height;
            jitterUV.z /= (float) width;
            jitterUV.w /= (float) height;

            // Set Shader properties
            reprojectionMaterial.SetVector("_JitterUV", jitterUV);
            reprojectionMaterial.SetFloat("_FeedbackMin", m_temporalReprojection.feedbackMin);                                                                           
            reprojectionMaterial.SetFloat("_FeedbackMax", m_temporalReprojection.feedbackMax);


            TemporalReprojection.SetShaderKeyword(reprojectionMaterial, TemporalReprojection.USE_YCOCG_KEYWORD, m_temporalReprojection.useYCoCg);
            TemporalReprojection.SetShaderKeyword(reprojectionMaterial, TemporalReprojection.USE_CLIPPING_KEYWORD, m_temporalReprojection.useClipping);
            TemporalReprojection.SetShaderKeyword(reprojectionMaterial, TemporalReprojection.USE_DILATION_KEYWORD, m_temporalReprojection.useDilation);
            TemporalReprojection.SetShaderKeyword(reprojectionMaterial, TemporalReprojection.UNJITTER_NEIGHBORHOOD_KEYWORD, m_temporalReprojection.UNJITTER_NEIGHBORHOOD);
            TemporalReprojection.SetShaderKeyword(reprojectionMaterial, TemporalReprojection.UNJITTER_REPROJECTION_KEYWORD, m_temporalReprojection.UNJITTER_REPROJECTION);
            TemporalReprojection.SetShaderKeyword(reprojectionMaterial, TemporalReprojection.UNJITTER_COLORSAMPLES_KEYWORD, m_temporalReprojection.UNJITTER_COLORSAMPLES);
            TemporalReprojection.SetShaderKeyword(reprojectionMaterial, TemporalReprojection.USE_OPTIMIZATIONS_KEYWORD, m_temporalReprojection.useOptimizations);
            EffectBase.EnsureKeyword(reprojectionMaterial, "USE_MINMAX_3X3", m_temporalReprojection.samplingMethod == TemporalReprojection.NeighborhoodSamplingMethod.MinMax_3x3);
            EffectBase.EnsureKeyword(reprojectionMaterial, "USE_MINMAX_3X3_ROUNDED", m_temporalReprojection.samplingMethod == TemporalReprojection.NeighborhoodSamplingMethod.MinMax_3x3_Rounded);
        }

       
        // RecordRenderGraph is where the RenderGraph handle can be accessed, through which render passes can be added to the graph.
        // FrameData is a context container through which URP resources can be accessed and managed.
        public override void RecordRenderGraph(RenderGraph renderGraph, ContextContainer frameData)
        {
            var handles = new TextureHandle[2];

            // Imports the texture handles them in RenderGraph.
            for (int i = 0; i < 2; i++)
            {
                handles[i] = renderGraph.ImportTexture(m_RTs[i]);
            }


            using (var builder = renderGraph.AddRasterRenderPass<BlitPassData>("Copy TR History Texture", out var passData))
            {   
                // Fetch the texture from the frame data 
                var customData = frameData.Get<AddOwnTexturePass.CustomData>();
                var historyBackBuffer = customData.newTextureForFrameData;

                if(!historyBackBuffer.IsValid() || !handles[0].IsValid())
                {
                    Debug.LogError("Temporal Reprojection: Invalid texture handle.");
                    return;
                }

                builder.SetRenderAttachment(historyBackBuffer, 0, AccessFlags.Write);

                // Add the texture to the pass data
                passData.textureToRead = handles[0];
                passData.material = m_Material;

                // Set the texture as readable
                builder.UseTexture(passData.textureToRead, AccessFlags.ReadWrite);

                builder.AllowPassCulling(false);

                builder.SetRenderFunc((BlitPassData data, RasterGraphContext rgContext) => 
                {
                    Blitter.BlitTexture(rgContext.cmd, data.textureToRead, new Vector4(1.0f,1.0f,0,0), 0, false);
                });
            }

            
            using (var builder = renderGraph.AddRasterRenderPass<PassData>(m_PassName, out var passData))
            {
                // Fetch the universal resource data to exstract the camera's color attachment.
                var resourceData = frameData.Get<UniversalResourceData>();

                // Fetch the texture from the frame data 
                var customData = frameData.Get<AddOwnTexturePass.CustomData>();
                var historyBackBuffer = customData.newTextureForFrameData;

                if(!historyBackBuffer.IsValid() || !handles[0].IsValid())
                {
                    Debug.LogError("Temporal Reprojection: Invalid texture handle.");
                    return;
                }
                
                // Use the camera's color attachment as input.
                passData.color = resourceData.activeColorTexture;
                passData.texName_color = m_texName_color;
                
                // Use the camera's depth attachment as input.
                passData.depth = resourceData.activeDepthTexture;
                passData.texName_depth = m_texName_depth;

                // Use the customData historyBackBuffer as input since we cant both read a texture that we set as one of the render targets.
                passData.history = historyBackBuffer;
                passData.texName_history = m_texName_history;

                // Use the camera's motion vectors attachment as input.
                passData.motionvectors = resourceData.motionVectorColor;
                passData.texName_motionvectors = m_texName_motionvectors;


                // Material used in the pass.
                passData.material = m_Material;


                SetMatieralProperties(passData.material, Screen.width, Screen.height);

                // Sets input attachments.
                builder.UseTexture(passData.color);
                builder.UseTexture(passData.depth);
                builder.UseTexture(passData.history);
                builder.UseTexture(passData.motionvectors);

                // Sets color attachments.
                for (int i = 0; i < 2; i++)
                {
                    builder.SetRenderAttachment(handles[i], i);
                }

                // Sets the render function.
                builder.SetRenderFunc((PassData data, RasterGraphContext rgContext) => ExecutePass(data, rgContext));

                resourceData.cameraColor = handles[1];
            }
        }


        static void ExecuteBlitPass(BlitPassData data, RasterGraphContext rgContext)
        {
            // Copy the imported texture to the render target
            Blitter.BlitTexture(rgContext.cmd, data.textureToRead, new Vector4(1.0f,1.0f,0,0), 0, false);
        }

        static void ExecutePass(PassData data, RasterGraphContext rgContext)
        {
            // Sets the input textures to the names used in the MRTPass
            data.material.SetTexture(data.texName_color, data.color);
            data.material.SetTexture(data.texName_depth, data.depth);
            data.material.SetTexture(data.texName_history, data.history);
            data.material.SetTexture(data.texName_motionvectors, data.motionvectors);
            
            // Draw the fullscreen triangle with the MRT shader.
            rgContext.cmd.DrawProcedural(Matrix4x4.identity, data.material, 0, MeshTopology.Triangles, 3);
        }
    }


    [Header("Screen Space Outlines Settings")]
    public Material vsNormalMaterial;
    public Material outlineMaterial;
    public Material nmsMaterial;
    public RenderPassEvent outlinesInjectionPoint = RenderPassEvent.AfterRenderingOpaques;
    [SerializeField] private OutlineMaterialSettings outlineMaterialSettings;

    

    [Header("Temporal Reprojection Anti-Aliasing Settings")]
    public Material TAAMaterial;
    public RenderPassEvent jitterInjectionPoint = RenderPassEvent.AfterRenderingPrePasses;
    public RenderPassEvent TAAInjectionPoint = RenderPassEvent.AfterRenderingTransparents;
    [SerializeField] private TemporalReprojection temporalReprojection = new TemporalReprojection();


    private AddOwnTexturePass m_CustomDataPass;
    private SSOutlinesPass m_OutlinePass;
    private TemporalReprojectionPass m_TemporalReprojectionPass;
    


    public override void Create()
    {
        m_TemporalReprojectionPass = new TemporalReprojectionPass();
        m_CustomDataPass = new AddOwnTexturePass();
        m_OutlinePass = new SSOutlinesPass();

        // Configures where the render passes should be injected.
        m_TemporalReprojectionPass.renderPassEvent = TAAInjectionPoint;
        m_CustomDataPass.renderPassEvent = jitterInjectionPoint;
        m_OutlinePass.renderPassEvent = outlinesInjectionPoint;

        temporalReprojection._frustumJitter.OnAwake();
    }


    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        if(TAAMaterial == null)
        {
            Debug.LogWarning("Temporal Reprojection Material is null and pass will be skipped.");
            return;
        }

        if(outlineMaterial == null || nmsMaterial == null || vsNormalMaterial == null)
        {
            Debug.LogWarning("Outline Material is null and pass will be skipped.");
            return;
        }

        Matrix4x4 projectionMatrix;
        if(temporalReprojection.useTAA && renderingData.cameraData.camera.cameraType != CameraType.SceneView)
        {
            temporalReprojection._frustumJitter._OnPreCull(renderingData.cameraData.camera);
            projectionMatrix = renderingData.cameraData.camera.GetProjectionMatrix(temporalReprojection._frustumJitter.activeSample.x, temporalReprojection._frustumJitter.activeSample.y);
            m_TemporalReprojectionPass.Setup(TAAMaterial, temporalReprojection);
        }
        else
        {
            projectionMatrix = renderingData.cameraData.camera.GetProjectionMatrix(0.0f, 0.0f);
        }

        m_CustomDataPass.Setup(projectionMatrix);
        m_OutlinePass.Setup(outlineMaterial, nmsMaterial, vsNormalMaterial, outlineMaterialSettings, temporalReprojection);
        
        renderer.EnqueuePass(m_CustomDataPass);
        renderer.EnqueuePass(m_OutlinePass);

        if(temporalReprojection.useTAA && renderingData.cameraData.camera.cameraType != CameraType.SceneView)
        {
            renderer.EnqueuePass(m_TemporalReprojectionPass);
        }
    }
}
