using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace EmmyVoitaMemoryGame
{
    public class CameraRotate : MonoBehaviour
    {
        public Transform target; // Target to follow
        public float distance = 10.0f; // Distance from the target
        public float speed = 5.0f; // Speed of horizontal rotation
        public float verticalAngle = 30.0f; // Vertical angle

        private float currentHorizontalAngle = 0.0f;

        // Start is called before the first frame update
        void Start()
        {
            if (target != null)
            {
                // Set the initial position of the camera
                UpdateCameraPosition();
            }
        }

        // Update is called once per frame
        void Update()
        {
            if (target != null)
            {
                // Automatically rotate horizontally
                currentHorizontalAngle += speed * Time.deltaTime;

                // Update the camera position
                UpdateCameraPosition();
            }
        }

        private void UpdateCameraPosition()
        {
            // Calculate the new position based on the vertical angle and horizontal rotation
            Quaternion rotation = Quaternion.Euler(verticalAngle, currentHorizontalAngle, 0);
            Vector3 offset = rotation * new Vector3(0, 0, -distance);

            // Update the camera position and look at the target
            transform.position = target.position + offset;
            transform.LookAt(target);
        }
    }
}