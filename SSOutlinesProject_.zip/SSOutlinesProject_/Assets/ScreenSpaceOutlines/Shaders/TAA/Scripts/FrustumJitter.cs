using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SSOutlines
{
    [System.Serializable]
    public class FrustumJitter 
    {

        private static Vector2[] points_Halton_2_3_x8 = new Vector2[8];
        private static Vector2[] points_Halton_2_3_x16 = new Vector2[16];
        private static Vector2[] points_Halton_2_3_x32 = new Vector2[32];
        private static Vector2[] points_Halton_2_3_x256 = new Vector2[256];

        

        // https://observablehq.com/@jrus/halton
        private static float ComputeHalton(int _index, int _base)
        {
            // _base: This is the prime number used to generate the sequence.
            // _index: This is the index of the number in the sequence you want to generate.

            float fraction = 1.0f;
            float result = 0.0f;

            while(_index > 0)
            {
                fraction /= _base;
                result += fraction * (_index % _base);
                _index = (int)Mathf.Floor(_index / (float) _base);
            }

            return result;
        }


        private static void InitializeHalton_2_3(Vector2[] seq)
        {
            // initialize the Halton sequence using the bases 2 and 3.
            for (int i = 0; i < seq.Length; i++)
            {
                float u = ComputeHalton(i + 1, 2) - 0.5f;
                float v = ComputeHalton(i + 1, 3) - 0.5f;
                seq[i] = new Vector2(u, v);
            }
        }

        

        static FrustumJitter()
        {
            // points_Halton_2_3_xN
            InitializeHalton_2_3(points_Halton_2_3_x8);
            InitializeHalton_2_3(points_Halton_2_3_x16);
            InitializeHalton_2_3(points_Halton_2_3_x32);
            InitializeHalton_2_3(points_Halton_2_3_x256);
        }

        public enum Pattern
        {
            Halton_2_3_X8,
            Halton_2_3_X16,
            Halton_2_3_X32,
            Halton_2_3_X256,
        };


        private static Vector2[] AccessPointData(Pattern pattern)
        {
            switch (pattern)
            {
                case Pattern.Halton_2_3_X8:
                    return points_Halton_2_3_x8;
                case Pattern.Halton_2_3_X16:
                    return points_Halton_2_3_x16;
                case Pattern.Halton_2_3_X32:
                    return points_Halton_2_3_x32;
                case Pattern.Halton_2_3_X256:
                    return points_Halton_2_3_x256;
                default:
                    Debug.LogError("missing point distribution");
                    return points_Halton_2_3_x16;
            }
        }

        public Vector2 Sample()
        {
            Vector2[] points = AccessPointData(pattern);

            int n = points.Length;
            subFrameNumber = (subFrameNumber + 1) % n;

            float x = patternScale * points[subFrameNumber].x;
            float y = patternScale * points[subFrameNumber].y;

            return new Vector2(x, y);
        }

        [SerializeField] private bool _firstFrame;
        public Pattern pattern = Pattern.Halton_2_3_X16;
        public float patternScale = 1.0f;
        private Vector3 focalMotionPos = Vector3.zero;
        private Vector3 focalMotionDir = Vector3.right;
        public Vector4 activeSample = Vector4.zero;// xy = current sample, zw = previous sample
        private int subFrameNumber;


        void OnClear()
        {
            //_camera.ResetProjectionMatrix();
            Debug.Log("OnClear");
            activeSample = Vector4.zero;
            _firstFrame = true;
        }

        public void OnAwake()
        {
            OnClear();
        }

        public void _OnPreCull(Camera _camera)
        {
            if(_firstFrame)
            {
                _firstFrame = false;

                activeSample = Vector4.zero;
            }
            else
            {
                Vector2 sample = Sample();
                activeSample.z = activeSample.x;
                activeSample.w = activeSample.y;
                activeSample.x = sample.x;
                activeSample.y = sample.y;
            }   
        }
    }
}
