// Copyright (c) <2015> <Playdead>
// This file is subject to the MIT License as seen in the root of this folder structure (LICENSE.TXT)
// AUTHOR: Lasse Jon Fuglsang Pedersen <lasse@playdead.com>

using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Experimental.Rendering;

public static class EffectBase 
{
    public static void EnsureArray<T>(ref T[] array, int size, T initialValue = default(T))
    {
        if (array == null || array.Length != size)
        {
            array = new T[size];
            for (int i = 0; i != size; i++)
                array[i] = initialValue;
        }
    }

    public static void EnsureArray<T>(ref T[,] array, int size0, int size1, T defaultValue = default(T))
    {
        if (array == null || array.Length != size0 * size1)
        {
            array = new T[size0, size1];
            for (int i = 0; i != size0; i++)
            {
                for (int j = 0; j != size1; j++)
                    array[i, j] = defaultValue;
            }
        }
    }

    public static void EnsureDepthTexture(Camera camera)
    {
        if ((camera.depthTextureMode & DepthTextureMode.Depth) == 0)
            camera.depthTextureMode |= DepthTextureMode.Depth;
    }

    public static void EnsureKeyword(Material material, string name, bool enabled)
    {
        if (enabled != material.IsKeywordEnabled(name))
        {
            if (enabled)
                material.EnableKeyword(name);
            else
                material.DisableKeyword(name);
        }
    }


    public static bool EnsureRenderTarget(ref RTHandle rtHandle, int width, int height, RenderTextureFormat format, FilterMode filterMode, int depthBits = 0)
    {
        if (rtHandle != null && (rtHandle.rt.width != width || rtHandle.rt.height != height || rtHandle.rt.format != format || rtHandle.rt.filterMode != filterMode))
        {
            RTHandles.Release(rtHandle);
            rtHandle = null;
        }

        if (rtHandle == null)
        {
            rtHandle = RTHandles.Alloc(width, height, depthBufferBits: (DepthBits)depthBits, colorFormat: GraphicsFormatUtility.GetGraphicsFormat(format, RenderTextureReadWrite.Default), filterMode: filterMode, wrapMode: TextureWrapMode.Clamp, dimension: TextureDimension.Tex2D, useDynamicScale: false, name: "_RenderTarget");
            return true; // new target
        }
        return false; // same target
    }

    public static bool EnsureRenderTarget(ref RenderTexture rt, int width, int height, RenderTextureFormat format, FilterMode filterMode, int depthBits = 0, int antiAliasing = 1)
    {
        if (rt != null && (rt.width != width || rt.height != height || rt.format != format || rt.filterMode != filterMode || rt.antiAliasing != antiAliasing))
        {
            RenderTexture.ReleaseTemporary(rt);
            rt = null;
        }
        if (rt == null)
        {
            rt = RenderTexture.GetTemporary(width, height, depthBits, format, RenderTextureReadWrite.Default, antiAliasing);
            rt.filterMode = filterMode;
            rt.wrapMode = TextureWrapMode.Clamp;
            return true;// new target
        }
        return false;// same target
    }

    public static void ReleaseRenderTarget(ref RTHandle rtHandle)
    {
        if (rtHandle != null)
        {
            RTHandles.Release(rtHandle);
            rtHandle = null;
        }
    }


    public static void ReleaseRenderTarget(ref RenderTexture rt)
    {
        if (rt != null)
        {
            RenderTexture.ReleaseTemporary(rt);
            rt = null;
        }
    }

    public static void DrawFullscreenQuad()
    {
        GL.PushMatrix();
        GL.LoadOrtho();
        GL.Begin(GL.QUADS);
        {
            GL.MultiTexCoord2(0, 0.0f, 0.0f);
            GL.Vertex3(0.0f, 0.0f, 0.0f); // BL

            GL.MultiTexCoord2(0, 1.0f, 0.0f);
            GL.Vertex3(1.0f, 0.0f, 0.0f); // BR

            GL.MultiTexCoord2(0, 1.0f, 1.0f);
            GL.Vertex3(1.0f, 1.0f, 0.0f); // TR

            GL.MultiTexCoord2(0, 0.0f, 1.0f);
            GL.Vertex3(0.0f, 1.0f, 0.0f); // TL
        }
        GL.End();
        GL.PopMatrix();
    }
}