using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace SSOutlines
{
    [System.Serializable]
	[ExecuteInEditMode]
    public class TemporalReprojection 
	{
		public enum NeighborhoodSamplingMethod
		{
			MinMax_3x3,
			MinMax_3x3_Rounded,
		}

	
		[SerializeField] public bool useTAA = true;
		[SerializeField] public NeighborhoodSamplingMethod samplingMethod = NeighborhoodSamplingMethod.MinMax_3x3_Rounded;
		[SerializeField] public bool useYCoCg = true;
		[SerializeField] public bool useClipping= true;
		[SerializeField] public bool useDilation = true;
		//[SerializeField] public bool UNJITTER_SAMPLES = true;
		[SerializeField] public bool UNJITTER_NEIGHBORHOOD = true;
		[SerializeField] public bool UNJITTER_COLORSAMPLES = true;
		[SerializeField] public bool UNJITTER_REPROJECTION = true; 
		[SerializeField] public bool useOptimizations = false;
		[SerializeField] [Range(0,1)] public float feedbackMin = 0.88f;
		[SerializeField] [Range(0,1)] public float feedbackMax = 0.97f;
		[SerializeField] public FrustumJitter _frustumJitter;



		private Camera camera;
		public Vector4 currentJitterVector { get; private set; }
		public Vector4 currentJitterVectorRaw { get; private set; }



		public const string USE_YCOCG_KEYWORD = "USE_YCOCG";
		public const string USE_CLIPPING_KEYWORD = "USE_CLIPPING";
		public const string USE_DILATION_KEYWORD = "USE_DILATION";
		public const string UNJITTER_NEIGHBORHOOD_KEYWORD = "UNJITTER_NEIGHBORHOOD";
		public const string UNJITTER_COLORSAMPLES_KEYWORD = "UNJITTER_COLORSAMPLES";
		public const string UNJITTER_REPROJECTION_KEYWORD = "UNJITTER_REPROJECTION";
		public const string USE_OPTIMIZATIONS_KEYWORD = "USE_OPTIMAZATIONS";
		public const string USE_MINMAX_3X3_KEYWORD = "USE_MINMAX_3X3";
		public const string USE_MINMAX_3X3_ROUNDED_KEYWORD = "USE_MINMAX_3X3_ROUNDED";

		public static readonly Dictionary<NeighborhoodSamplingMethod, string> NeighborhoodSamplingMethodKeywords = new Dictionary<NeighborhoodSamplingMethod, string>
		{
			{ NeighborhoodSamplingMethod.MinMax_3x3, USE_MINMAX_3X3_KEYWORD },
			{ NeighborhoodSamplingMethod.MinMax_3x3_Rounded, USE_MINMAX_3X3_ROUNDED_KEYWORD }
		};

		
		public void OnUpdate()
		{
			if(camera == null)
			{
				camera = Camera.main;
			}

			currentJitterVector = useTAA == true ? GetJitterUV() : Vector4.zero;
		}


		public Vector4 GetJitterUV()
		{
			Vector4 jitterUV = _frustumJitter.activeSample;
			jitterUV.x /= camera.pixelWidth;
			jitterUV.y /= camera.pixelHeight;
			jitterUV.z /= camera.pixelWidth;
			jitterUV.w /= camera.pixelHeight;
		
			///currentJitterVectorRaw = frameJitter;
			//frameJitter.x /= camera.pixelWidth;
			//frameJitter.y /= camera.pixelHeight;
			return jitterUV;
		}


		public static void SetNeighborhoodSamplingMethodKeyword(Material material, NeighborhoodSamplingMethod selectedMethod)
        {
            foreach (var kvp in NeighborhoodSamplingMethodKeywords)
            {
                if (kvp.Key == selectedMethod)
                {
                    material.EnableKeyword(kvp.Value);
                }
                else
                {
                    material.DisableKeyword(kvp.Value);
                }
            }
        }

		public static void SetShaderKeyword(Material material, string keyword, bool state)
		{
			
			if (state)
			{
				material.EnableKeyword(keyword);
			}
			else
			{
				material.DisableKeyword(keyword);
			}
		}
	}
}
