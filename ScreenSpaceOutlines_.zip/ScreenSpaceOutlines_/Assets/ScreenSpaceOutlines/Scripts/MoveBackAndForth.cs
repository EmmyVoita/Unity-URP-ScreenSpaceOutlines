using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveBackAndForth : MonoBehaviour
{
    public Vector3 startPoint = new Vector3(0, 0, 0); // Starting position
    public Vector3 endPoint = new Vector3(5, 0, 0);   // Ending position
    public float speed = 2f;                          // Movement speed

    private void Update()
    {
        // Interpolate between startPoint and endPoint using Mathf.PingPong
        float t = Mathf.PingPong(Time.time * speed, 1f); // Smoothly oscillates between 0 and 1
        transform.position = Vector3.Lerp(startPoint, endPoint, t); // Smooth movement
    }
}

